extern void define_scroll_line(unsigned x, unsigned y, unsigned len);
extern void display_in_line(unsigned char  byte);
