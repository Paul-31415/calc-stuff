PLEASE NOTE: If you have a TI-83+, TI-83+SE, TI-84+, or TI-84+SE,
             you are in the WRONG FOLDER.  Go up one level and
             send DoorsCS7.8xk to your calculator.

THIS IS NOT FOR THE TI-83+/SE or TI-84+/SE or TI-Nspire!