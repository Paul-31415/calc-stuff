
Sky by Robert Kuhfss [NanoWar]
==============================================
A Revolution Software Production [revsoft.org]

Version: 2
Release date: 03 August 2009

Thank you for downloading Sky!

To complete a level you just have to fill in every white part of it with the use of the arrow keys.

You need a shell to run this asm program (see below).

shells:
NOSHELL - http://www.ticalc.org/archives/files/fileinfo/400/40005.html
MIRAGEOS - http://www.ticalc.org/archives/files/fileinfo/139/13949.html
ION - http://www.ticalc.org/archives/files/fileinfo/130/13059.html

menu keys:
[2nd] starts the chosen level
[Arrow keys] set difficulty and level
[Mode] quits
[Sto->] deletes the save game

in game keys:
[Clear] resets the level
[Arrow keys] move all cursors in the chosen direction
[Mode] returns to the menu

files:
"sky.8xp" is the TI83+/84+ file
"sky.83p" is the TI83 file
"sky.gif" is the screen shot
"/source" is the source code folder

Licence: http://creativecommons.org/licenses/by-nc-sa/3.0/

