___________  ____________________________   __
___    |_  |/ /__    |_  ____/_  __ \__  | / /
__  /| |_    /__  /| |  / __ _  / / /_   |/ / 
_  ___ |    | _  ___ / /_/ / / /_/ /_  /|  /  
/_/  |_/_/|_| /_/  |_\____/  \____/ /_/ |_/   
                                              

By Matrefeytontias
Based on Hexagon by Terry Cavanagh
----------------------------------

This package includes both the game and the source code. AXAGON.8xp is the game itself, which you shall run on the homescreen of your TI-83+/84+ with the Asm( command, and all the other .8xp files are source code files.

In case you can't guess it when playing the game (come on, you're not even trying), the game is played by dodging the walls coming at you with the left and right arrows.
Of course, it gets harder as you survive longer. Good luck beating 60 seconds, 'cause you'll need even more luck to beat 120 seconds.
The game never tells you, but there's a teacher key. Press [clear] anywhere in the game to instantly close it and get back to the homescreen.
Your highest score is saved for your convenience.

----------------------------------
For comments and/or help, mail me at mattias@refeyton.fr

You can look at my source code and modify it for learning purposes (obviously, I mean, I do provide it), but please don't be an asshole and distribute it under your own name. That's all I ask. Have fun o/