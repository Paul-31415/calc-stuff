Programming in System RPL
-------------------------

Read me file


A couple of notes regarding the "Programming in System RPL" book:

- This document may be redistributed only if in its whole, unmofied
  form; and if you do not charge anything for it (expect nominal
  copying fees).

- If you find any error in it, please contact Eduardo
  (ekalin@bol.com.br) or Carsten (dominik@science.uva.nl).

- The most up-to-date errata of this document can be found at
  http://move.to/hpkb . There is also a mailing list for distribution
  of the newest errata. To subscribe this mailing list, send an empty
  e-mail to ProgSysRPL_errata-subscribe@yahoogroups.com .



April 24, 2002
Eduardo M Kalinowski
Carsten Dominik
