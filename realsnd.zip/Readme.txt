RealSound v1.0
  Created by James Montelongo
Wave Converter
  Created by James Montelongo
Wabbitsign
  Created by James Montelongo and Spencer Putt

Email @ :  James20@revsoft.org
WWW @ : www.Revsoft.org
See our forums @ http://www.revsoft.org/phpBB2/

SEE A DEMO OF REALSOUND IN ACTION HERE:

http://www.revsoft.org/vids/realsnd.mpg


Files included:
makewav.bat
marioshort.wav
play.bin
Readme.txt
Wabbitsign.exe
WaveConv.exe


This package will allow you to create Applications capable of high quality sound for any SE calculator(84+included). This requires that you have a 2.5mm to 3.5mm audio jack convertor, you can pick one up at radioshack.

To use, at the comandline enter in the following:

makewav SONG.wav APP.8xk

SONG.wav must be an uncompressed wav file. The sample rate can be between 256hz through 32khz. If the audio is 16 bit it will be converted to 8bit. Bit widths other than 16 or 8 are not supported.  If multichannel sound is used, only the left channel will be converted, So for high quality please convert prior. One last thing, the volume on the calcs is quite low, I suggest making the volume louder through a sound program such as windows Recorder. Do so as much as possible. Or you could alternatively use speakers which yield better sound.

App.8xk can be named anything but it must end in .8xk. This does not reflect the name on the calc.

!!!!!PLEASE MAKE SURE YOU ARE USING THE NEWEST VERSION OF TI-CONNECT.!!!!
There have been reports of errors during sending, please update TI-CONNECT and try sending again, you may get the error but just repeat sending. Ti-Coneect does not like sending big files.

Before the program finishes it will display the total size. PLEASE MAKE SURE THAT AMOUNT IS AVAILBLE BEFORE SENDING.

Before sending, delete older versions, and do a garbage collect. Hopefully this will increase the chance of a successful send.

If there is any trouble please email me or contact me on the revsoft forum.

If you wish just run a.bat to make the mario sound byte. :)

I am not responsible for any damages that may occur during use of this program, though nothing should bad happen.