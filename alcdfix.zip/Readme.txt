LCD FIX
Created by James Montelongo
James20@gmail.com

Only for the 83+se, 84+, and 84+se
NOT 83+
This will alter driver settings in order
to work around the bad drivers that 
TI has been installing on new model
Calculators.

Symptoms of bad LCD driver
*wavy screen
* only 2/3 of the screen working
*complete distortion


Usage
You  may run this from MirageOS, 
ION, or even the Home Screen,

ASM(prgmALCDFIX)

It will display a warning saying it
may take 10 seconds, press Enter.
Now you should see what looks
like static on the screen. Allow
this to run and it should display 
my name and the driver setting
used. This will be between 4 and 
64.

Now test one of your buggy games
to see if it worked.

Please Email me if this was
successful, or didn't fix every game.
Include:
*Calculator Model
*Driver setting 
*Game not fixed, if applicable

This is a temporary Fix, it will
undo if you pull out the batteries
and some programs may affect the 
driver setting. So keep this program
in your archive and run when needed.

This problem was created by TI
for installing defective Drivers in 
their calculators. It is not the fault
of the programmers who created
the games, or MirageOS.
Please DO NOT bug these people
demanding a fix.

Call TI and complain to them at
800-TI-CARES (800-842-2737)

If enough people call they may
actually do something about it.

